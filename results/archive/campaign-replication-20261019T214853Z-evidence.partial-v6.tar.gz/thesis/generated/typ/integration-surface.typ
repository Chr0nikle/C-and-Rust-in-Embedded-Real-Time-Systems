#text(size: 8pt)[The shared contract has 83 Rust `Port` methods and 82 C `bench_port` function pointers. The shared runner is 489 code lines in C and 636 in Rust (protocol session and case dispatch).]

#figure(
  text(size: 7.5pt, table(
    columns: (auto, 1fr, 1fr, 1fr, 1fr, 1fr),
    stroke: (x: none, y: 0.25pt + luma(210)),
    inset: (x: 3pt, y: 1.5pt),
    column-gutter: 2pt,
    align: (left, center, center, center, center, center),
    table.header(
      table.cell(fill: luma(235))[*System*],
      table.cell(fill: luma(235))[*Adapter C*],
      table.cell(fill: luma(235))[*Adapter Rust*],
      table.cell(fill: luma(235))[*cfg branches*],
      table.cell(fill: luma(235))[*staged patches*],
      table.cell(fill: luma(235))[*build files*],
    ),
  [freertos], [14109], [1893], [181], [0], [0],
  [freertos-in-rust], [0], [1771], [28], [0], [0],
  [nuttx], [0], [2050], [1], [3], [0],
  [rivet], [0], [1794], [2], [0], [0],
  [zephyr], [12603], [2081], [100], [2], [0],
  )),
  caption: [Integration surface by system],
) <integration-surface>
