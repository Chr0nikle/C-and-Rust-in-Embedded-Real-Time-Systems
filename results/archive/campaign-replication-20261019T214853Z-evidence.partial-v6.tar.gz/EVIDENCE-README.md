# PARTIAL thesis evidence archive

Campaign: campaign-replication-20261019T214853Z
Created: 2026-10-21T06:24:34Z
Complete: no

Verify with:

    python3 project/scripts/maintenance/archive_evidence.py --verify ARCHIVE

EVIDENCE-MANIFEST.sha256 lists every payload file with its SHA-256.

## Missing evidence

- supplementary bundle campaign-replication-20261014T075134Z (missing)
